Resolution: 2560 × 1440
and tested at 1080p